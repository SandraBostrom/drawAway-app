package com.example.drawawaytest.Cards;

public class Cards {


    private String userId;
    private String name;

    private String profilBildUrl;

    public Cards(String userId, String name, String profilBildUrl){
        this.userId = userId;
        this.name = name;
        this.profilBildUrl = profilBildUrl;

    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfilBildUrl() {
        return profilBildUrl;
    }

    public void setProfilBildUrl(String profilBildUrl) {
        this.profilBildUrl = profilBildUrl;
    }
}
